//
//  AppDelegate.h
//  Project Checker
//
//  Created by のんのん on 2022/07/06.
//

#import <Cocoa/Cocoa.h>


@interface AppDelegate : NSObject <NSApplicationDelegate>
@end

